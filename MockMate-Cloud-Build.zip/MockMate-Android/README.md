# MockMate Android project

This is an Android WebView wrapper around the MockMate 2.0 mobile web app.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `MockMate-Android` folder as a project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations
- This project is source/build setup, not a compiled APK. An Android SDK/Gradle build environment is required to produce and verify the APK.
- The included question bank is a small generated-practice demo. It does not yet include independently verified official PYQs.
- Test history is stored locally on the device/browser WebView storage.
